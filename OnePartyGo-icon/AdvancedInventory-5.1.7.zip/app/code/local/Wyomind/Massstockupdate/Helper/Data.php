<?php

class Wyomind_Massstockupdate_Helper_Data extends Mage_Core_Helper_Abstract
{

    

}
